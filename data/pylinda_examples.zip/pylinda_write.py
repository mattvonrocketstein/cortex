#!/usr/bin/python
import linda
linda.connect()
ts = linda.universe._rd(("MiG-TEST", linda.TupleSpace))[1]
ts._out((3, 4, 5))

