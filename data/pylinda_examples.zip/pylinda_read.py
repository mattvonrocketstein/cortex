#!/usr/bin/python
import linda
linda.connect()
ts = linda.universe._rd(("MiG-TEST", linda.TupleSpace))[1]
result = ts._in((int, int, int))
print "Result: %s" % (str(result))

