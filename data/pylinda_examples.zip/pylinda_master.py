#!/usr/bin/python
import linda
linda.connect()
ts = linda.TupleSpace()
linda.universe._out(("MiG-TEST", ts))
